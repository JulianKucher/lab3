LAB#3

![lab3pick](https://user-images.githubusercontent.com/21161653/32935641-af62ca40-cb79-11e7-803d-9d712a1a71df.png)
